import java.util.ArrayList;
public class ChoiceQuestion extends Question {
    private ArrayList<String> choices = new ArrayList<String>();
    public ChoiceQuestion(String text){
        super(text);
    }
    
    public void addChoice(String choice, boolean correct){
        choices.add(choice);
        if(correct)
           super.setAnswer(choice);
    }
    
    @Override
    public void display(){
        System.out.println(super.getText());
        for(int i=1; i<choices.size()+1; i++){
            System.out.printf("%d: %s%n",i,choices.get(i-1));
        }
    }
    
    @Override
    public boolean checkAnswer(String response){
        int choice = Integer.parseInt(response);
        return choices.get(choice-1).equalsIgnoreCase(super.getAnswer());
    }
}
