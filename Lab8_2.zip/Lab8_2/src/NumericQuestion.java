import java.lang.Math;
public class NumericQuestion extends Question {
    public NumericQuestion(String text){
        super(text);
    }
    
    @Override
    public boolean checkAnswer(String response){
        double resp = Double.valueOf(response);
        double ans = Double.valueOf(super.getAnswer());
        return (Math.abs(resp-ans) < 0.01);
    }
}

