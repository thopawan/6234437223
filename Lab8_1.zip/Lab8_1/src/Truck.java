public class Truck extends Car{
    private double maxWeight,weight;
    public Truck(double gas, double eff, double maxWeight, double weight){
        super(gas,eff);
        this.maxWeight = maxWeight;
        if(weight>maxWeight)
            this.weight = maxWeight;
        else
            this.weight = weight;
    }
    
    @Override
    public void drive(double distance){
        double factor = 1.0;
        if(weight<1)
            factor = 1.0;
        else if(weight<=10)
            factor = 1.1;
        else if(weight<=20)
            factor = 1.2;
        else if(weight>20)
            factor = 1.3;
        
        if(super.getGas()-((distance/super.getEfficiency())*factor) < 0)
            System.out.println("You cannot drive too far, please add gas.");
        else
            super.setGas(super.getGas()-((distance/super.getEfficiency())*factor));
    }
}
