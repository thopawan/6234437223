interface Evaluation {
	double evaluate();
	char grade(double s);
}
