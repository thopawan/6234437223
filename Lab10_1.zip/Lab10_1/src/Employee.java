public class Employee {
	private String name;
	private int salary;
	
	public Employee(String st, int s) {
		name = st;
		salary = s;
	}
	
	public void setSalary(int s) 
		{salary = s;}
	
	@Override
	public String toString() {
		return name + "\nsalary = " + salary;
	}
}
