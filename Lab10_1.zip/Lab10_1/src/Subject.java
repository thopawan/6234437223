public class Subject implements Evaluation {
	private String subjName;
	private int[] score;
	
	public Subject(String sn, int[] s) {
		subjName = sn;
		score = s;
	}

	@Override
	public double evaluate() {
		int SumScore = 0;
		for(int x: score)
			SumScore += x;
		return SumScore/score.length;
	}

	@Override
	public char grade(double s) {
		if(s>=70) 
			return 'P';
		else
			return 'F';
	}
	
	public String toString() {
		return subjName;
	}
	

}
