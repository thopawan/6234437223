public class Secretary extends Employee implements Evaluation {
	private int typingSpeed;
	private int[] score;
	public Secretary(String st, int s, int[] score, int ts) {
		super(st, s);
		typingSpeed = ts;
		this.score = score;
	}
	
	@Override
	public double evaluate() {
		int totalScore = 0;
		for(int x: score)
			totalScore += x;
		return totalScore;
	}
	
	@Override
	public char grade(double s) {
		if(s>=90) {
			super.setSalary(18000);
			return 'P';
		}
		
		else
			{return 'F';}
	}

}
