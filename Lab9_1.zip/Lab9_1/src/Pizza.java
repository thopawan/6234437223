class Pizza {
    private String name;
    private double price;
    public Pizza(String n, double p){
        name = n;
        price = p;
    }
    
    public String getName()
        {return name;}
    
    public double getPrice()
        {return price;}
    
    @Override
    public String toString()
        {return this.getName() + " Price : " + this.getPrice();}
}