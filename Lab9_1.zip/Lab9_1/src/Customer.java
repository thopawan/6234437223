class Customer {
    private String name,tel;
    public Customer(String n, String t){
        name = n;
        tel = t;
    }
    
    public String getName()
        {return name;}
    
    public String getTel()
        {return tel;}
    
    @Override
    public String toString()
        {return this.getName() + " Tel : " + this.getTel();}
}
