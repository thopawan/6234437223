import java.util.ArrayList;
class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<Pizza>();
   
    public Order(Customer c){
        this.c = c;
        cntOrder++;
    }
    
    public void addPizza(Pizza pizza){
        p.add(pizza);
    }
    
    public String getOrderDetail(){
        String st = "Order id : " + cntOrder + "\n";
        st += c.toString() + "\n";
        for (Pizza pi : p)
            st += pi.toString() + "\n";
        st += "Total pieces : " + p.size() + "\n";
        st += "Total cost : " + this.calculatePayment();
        
        return st;
    }
       
    public double calculatePayment(){
        double totalPrice=0,discount=0;
        for(Pizza pi : p)
            totalPrice += pi.getPrice();
        
        //Downcasting
        if (c instanceof GoldCustomer){
            GoldCustomer gc = (GoldCustomer) c;
            discount = gc.getDiscount();
        }
        
        return totalPrice*((100-discount)/100);
    }
    
}
