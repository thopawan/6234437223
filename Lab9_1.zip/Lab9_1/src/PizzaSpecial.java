class PizzaSpecial extends Pizza {
    private String special;
    
    public PizzaSpecial(String n, double p, String s){
        super(n,p);
        special = s;
    }
    
    @Override
    public String toString()
        {return this.getName() + " Price : " + this.getPrice() + " Special : " + special;}
}