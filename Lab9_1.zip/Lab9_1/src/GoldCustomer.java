class GoldCustomer extends Customer {
    private double discount;
    public GoldCustomer(String n, String t, double d){
        super(n,t);
        discount = d;
    }
    
    public double getDiscount()
        {return discount;}
    
    @Override
    public String toString()
        {return this.getName() + " Tel : " + this.getTel() + " Discount : " + this.getDiscount();}
}
