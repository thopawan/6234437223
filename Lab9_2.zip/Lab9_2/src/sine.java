import java.lang.Math;
public class sine extends Taylor {
	public sine(int k, double x) 
		{super(k,x);}
	
	public void printValue() {
		System.out.printf("Value from Math.sin() is %.16f.%n", Math.sin(this.getValue()));
		System.out.printf("Approximate value is %.16f.%n", this.getApprox());
	}
	
	public double getApprox() {
		double ans = 0;
		for(int i = 0; i<=this.getIter(); i++)
			ans += (Math.pow(-1, i) * Math.pow(this.getValue(), 2*i+1)) / this.factorial(2*i+1);
		return ans;
	}
}
