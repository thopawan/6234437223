import java.lang.Math;
public class expo extends Taylor {
	public expo(int k, double x) 
		{super(k,x);}
	
	public void printValue() {
		System.out.printf("Value from Math.exp() is %.16f.%n", Math.exp(getValue()));
		System.out.printf("Approximate value is %.16f.%n", this.getApprox());
	}
	
	public double getApprox() {
		double ans = 0;
		for(int i = 0; i<=this.getIter(); i++)
			ans += Math.pow(this.getValue(),i) / this.factorial(i);
		return ans;
	}
}
