package lab3_1;

public class InsectPopulation {
    private double population;
    
    public InsectPopulation(double n){
        population = n;
    }
    
    public void breed(){
        population *= 2;
    }
    
    public void spray(){
        population *= 0.9;
    }
    
    public double getNumInsect(){
        return(population);
    }
}