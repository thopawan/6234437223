package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Tester {

    public static void main(String[] args) throws FileNotFoundException {
        String string = "";
        Scanner scanner = new Scanner(System.in);
        boolean fl = true;
        int lineCnt = 0;
        int wordCnt = 0;
        int charCnt = 0;

        System.out.println("*You may now start typing (type quit to exit)*");

        while (true) {
            String line = scanner.nextLine();
            if (line.equals("quit")) {
                break;
            }
            else {
                if (!fl) {
                    string += "\n";
                    string += line;
                }
                else {
                    string += line;
                    fl = false;
                }
            }
        }
        File file = new File("output.txt");
        PrintWriter output = new PrintWriter(file);
        output.print(string);
        output.close();

        Scanner read = new Scanner(file);
        while (read.hasNextLine()) {
            String line = read.nextLine();
            lineCnt++;
            String[] words = line.split(" ");
            wordCnt += words.length;          
            charCnt += line.length();
        }
        read.close();
        System.out.println("Total characters : "+charCnt);
        System.out.println("Total words : "+wordCnt);
        System.out.println("Total lines : "+lineCnt);
    }

}
    

