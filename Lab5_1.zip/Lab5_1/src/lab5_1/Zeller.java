package lab5_1;

public class Zeller {
    
    private int dayOfMonth ;
    private int month;
    private int year;
    private int h,q,m,j,k ;
   
    
    public Zeller(int d, int m, int y){
        dayOfMonth = d ;
        month = m ;
        year = y ;
    
    }
    public enum Day
    {
        SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY ;
    }
    
    public Day getDayOfWeek()
    {
        q = dayOfMonth ;
        m = month ;
        if(m == 1){
            year -= 1 ;
            m = 13 ;
          }
        if(m == 2){
            year -= 1 ;
            m = 14 ;
          }
        j = year/100 ;
        k = year%100 ;
        h = (q+((26*(m+1))/10)+k+(k/4)+(j/4)+(5*j))%7 ;
        Day dayInWord = Day.SUNDAY;
        
        if(h == 1){
            dayInWord = Day.SUNDAY ;
        }
        if(h == 2){
            dayInWord = Day.MONDAY ;
        }
        if(h == 3){
            dayInWord =Day.TUESDAY ;
        }
        if(h == 4){
            dayInWord =Day.WEDNESDAY ;
        }
        if(h == 5){
            dayInWord =Day.THURSDAY ;
        }
        if(h == 6){
            dayInWord =Day.FRIDAY ;
        }
        if(h == 0){
            dayInWord =Day.SATURDAY ;
        }
        
        return dayInWord ;
        

    }
}
