public interface LiquidFuel {
	double getRange();
	int getEmissionTier();
}
