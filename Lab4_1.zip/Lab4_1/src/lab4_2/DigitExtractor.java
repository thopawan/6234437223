package lab4_2;
import java.lang.Math;
public class DigitExtractor {
    private int digitCounter = 1, integer = 0;
    public DigitExtractor(int anInteger) {
        integer = anInteger;
    }

    public int nextDigit(){
        int x = (int) (integer % Math.pow(10,digitCounter) / Math.pow(10,digitCounter-1));
        digitCounter += 1;
        return(x);
    }
}
