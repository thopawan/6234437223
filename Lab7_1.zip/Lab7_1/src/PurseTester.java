import java.util.ArrayList;
class Purse 
{
    private ArrayList<String> purse1;
    public Purse()
            {
                purse1 = new ArrayList<String>();
            }
    public void addCoin(String coinName)
    {
        purse1.add(coinName);
    }
    
    public String toString()
    {
        String outputPurse ="";
        for(int i = 0;i < purse1.size() ; i++)
        {
            outputPurse +=  purse1.get(i);
            if(i<purse1.size()-1) outputPurse += ",";
        }
        return "Purse["+outputPurse+"]";
    }
    
    public ArrayList<String> reverse()
    {
         ArrayList<String> purse2 = new ArrayList<String>();
        for(int i = purse1.size()-1;i >= 0 ; i--)
        {
            purse2.add(purse1.get(i));          
        }
        purse1 = purse2;
       return purse1;
    }
    
    public void transfer(Purse other)
    {
        int csize = purse1.size();
        for(int i = 0; i < csize ; i++)
        {
            other.purse1.add(purse1.get(0));
            purse1.remove(0);
        }
    }
    
    public boolean sameContents(Purse other)
    {
        boolean ch =true;
        if(other.purse1.size()!= purse1.size()) ch =false;
        else for(int i = 0 ; i < purse1.size() ; i++)
        {
            if(other.purse1.get(i)!= this.purse1.get(i)) 
            {
                ch = false;
                break;
            }
        }
        return ch;
    }
    
    public boolean sameCoins(Purse other)
    {
       boolean ch =true;
        if(other.purse1.size()!= purse1.size()) ch =false;
        else for(int i = 0 ; i < purse1.size() ; i++)
        {
            int coin1 = 0;
            int coin2 = 0;
            for(int j = 0 ; j < purse1.size() ; j++)
            {
                if(purse1.get(i)==purse1.get(j))
                    coin1++;
                if(purse1.get(i)==other.purse1.get(j))
                    coin2++;
            }
            if(coin1 != coin2)
            {
                ch = false;
                break;
            }
        }
        return ch; 
    }
}
public class PurseTester {

    public static void main(String[] args) {
        Purse a = new Purse();
        Purse b = new Purse();
        a.addCoin("cc");
        a.addCoin("SS");
        a.addCoin("bb");
        a.addCoin("cc");
        
        b.addCoin("cc");
        b.addCoin("SS");
        b.addCoin("bb");
        b.addCoin("cc");
        a.reverse();
        System.out.println(a.toString());
        System.out.println(b.toString());
        System.out.println(a.sameCoins(b));
        System.out.println(a.sameContents(b));
    }
    
}
