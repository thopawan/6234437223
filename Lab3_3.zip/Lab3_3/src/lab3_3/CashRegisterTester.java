/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author usci
 */
public class CashRegisterTester {
    public static void main(String[] args){
        CashRegister x = new CashRegister(7);
        x.recordPurchase(50);
        x.recordPurchase(10);
        x.recordTaxablePurchase(20);
        x.enterPayment(100);
        System.out.println("Your change is "+x.giveChange());

    }
}
