/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author usci
 */
public class CashRegister {
    private double paymentAmount,purchaseAmount,taxRate,totalTax = 0;
    public CashRegister(double tax){
        paymentAmount = 0;
        purchaseAmount = 0;
        taxRate = tax;
    }
    public void recordPurchase(double amount){
        purchaseAmount += amount;
    }
    
    public void recordTaxablePurchase(double amount){
        purchaseAmount += amount;
        totalTax += amount*(taxRate/100);
    }
    
    public void enterPayment(double amount){
        paymentAmount += amount;
    }
   
    public double getTotalTax(){
        return(totalTax);
    }
    
    public double giveChange(){
        double change = paymentAmount - purchaseAmount - totalTax;
        paymentAmount = 0;
        purchaseAmount = 0;
        return(change);
    }
    
    
}
