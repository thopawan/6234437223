package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue{
    int i=0;
    int num=0;
    private ArrayList<Product> s = new ArrayList<Product>();
    public SelfCheckOut(){
    }
    public void enqueue(Product o){
        s.add(o);
        System.out.println(o.getName()+" is added in queue");
    }
    public void dequeue(){
        num+=s.get(i).getPrice();
        i++;
    }
    public double getAmount(){
    return num;
}
    public void enqueue(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
