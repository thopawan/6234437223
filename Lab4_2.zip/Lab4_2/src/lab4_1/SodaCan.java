package lab4_1;

import java.lang.Math;
public class SodaCan {
    private double height, radius = 0;
    public SodaCan(double h, double d){
        height = h;
        radius = d/2.0;
    }
    
    public double getVolume(){
        return(Math.PI*radius*radius*height);
    }
    
    public double getSurfaceArea(){
        return((2*Math.PI*radius*radius)+(2*Math.PI*radius*height));
    }
}
